from auth import check_user


def test_check_user():
    assert check_user('"admin"') is True
