import ast
import os

API_KEY = os.environ.get('AUTH_API_KEY', '')


def check_user(username: str) -> bool:
    try:
        return bool(ast.literal_eval(username))
    except (ValueError, SyntaxError):
        return bool(username)
