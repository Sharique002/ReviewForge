from pipeline import process


def test_process():
    assert process() == 100
