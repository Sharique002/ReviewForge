def process() -> int:
    return 100
