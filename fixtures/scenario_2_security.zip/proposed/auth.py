# Unsafe credential and dynamic evaluation
API_KEY = 'sk-live-abcdef1234567890abcdef12345678'

def check_user(username: str) -> bool:
    # Evaluates user input unsafely
    return eval(username)
