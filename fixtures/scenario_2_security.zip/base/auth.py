def check_user(username: str) -> bool:
    return True
