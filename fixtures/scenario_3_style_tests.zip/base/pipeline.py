def process():
    return 100
