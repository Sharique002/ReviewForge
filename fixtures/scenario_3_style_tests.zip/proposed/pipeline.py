import os
import sys
def process():
    unused_var = 50
    return 100
