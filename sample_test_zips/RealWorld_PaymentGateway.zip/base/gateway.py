"""Payment Gateway Integration."""
import uuid
from typing import Dict, Any


class PaymentGateway:
    def __init__(self, merchant_id: str):
        self.merchant_id = merchant_id
        self._processed_transactions: Dict[str, Dict[str, Any]] = {}

    def charge(self, amount_cents: int, currency: str, card_token: str) -> Dict[str, Any]:
        if amount_cents <= 0:
            raise ValueError("Amount must be greater than zero.")
        if not card_token or len(card_token) < 5:
            raise ValueError("Invalid card payment token.")

        transaction_id = f"txn_{uuid.uuid4().hex[:12]}"
        record = {
            "transaction_id": transaction_id,
            "merchant_id": self.merchant_id,
            "amount_cents": amount_cents,
            "currency": currency.upper(),
            "status": "SUCCEEDED"
        }
        self._processed_transactions[transaction_id] = record
        return record
