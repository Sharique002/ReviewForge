"""E-Commerce Core Domain Models."""
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class OrderItem:
    sku: str
    quantity: int
    unit_price_cents: int


@dataclass
class CustomerOrder:
    order_id: str
    customer_id: str
    items: List[OrderItem]
    currency: str = "USD"
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def total_amount_cents(self) -> int:
        return sum(item.unit_price_cents * item.quantity for item in self.items)
