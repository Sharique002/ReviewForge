"""Unit tests for PaymentGateway."""
from gateway import PaymentGateway
import pytest


def test_successful_charge():
    gw = PaymentGateway(merchant_id="merch_100")
    res = gw.charge(amount_cents=4500, currency="USD", card_token="tok_visa_valid")
    assert res["status"] == "SUCCEEDED"
    assert res["amount_cents"] == 4500
    assert res["currency"] == "USD"


def test_invalid_amount_rejected():
    gw = PaymentGateway(merchant_id="merch_100")
    with pytest.raises(ValueError, match="greater than zero"):
        gw.charge(amount_cents=0, currency="USD", card_token="tok_visa_valid")
