"""E-Commerce Core Domain Models (Upgraded with Idempotency & Refunds)."""
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class OrderItem:
    sku: str
    quantity: int
    unit_price_cents: int


@dataclass
class RefundRequest:
    refund_id: str
    original_transaction_id: str
    amount_cents: int
    reason: str
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class CustomerOrder:
    order_id: str
    customer_id: str
    items: List[OrderItem]
    currency: str = "USD"
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def total_amount_cents(self) -> int:
        return sum(item.unit_price_cents * item.quantity for item in self.items)
