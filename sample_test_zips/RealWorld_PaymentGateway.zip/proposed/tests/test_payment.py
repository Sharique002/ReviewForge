"""Comprehensive unit tests for upgraded PaymentGateway."""
from gateway import PaymentGateway
import pytest
import hmac
import hashlib


def test_successful_charge():
    gw = PaymentGateway(merchant_id="merch_100")
    res = gw.charge(amount_cents=4500, currency="USD", card_token="tok_visa_valid")
    assert res["status"] == "SUCCEEDED"
    assert res["amount_cents"] == 4500


def test_idempotency_protection():
    gw = PaymentGateway(merchant_id="merch_100")
    key = "idem_key_unique_99"
    res1 = gw.charge(amount_cents=5000, currency="EUR", card_token="tok_mastercard", idempotency_key=key)
    res2 = gw.charge(amount_cents=5000, currency="EUR", card_token="tok_mastercard", idempotency_key=key)

    # Identical transaction returned without duplicate processing
    assert res1["transaction_id"] == res2["transaction_id"]


def test_webhook_signature_verification():
    secret = "whsec_test_secret_key"
    gw = PaymentGateway(merchant_id="merch_100", webhook_secret=secret)
    body = b'{"event": "payment_intent.succeeded", "id": "pi_123"}'
    valid_sig = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()

    assert gw.verify_webhook_signature(body, valid_sig) is True
    assert gw.verify_webhook_signature(body, "invalid_sig_abc123") is False
