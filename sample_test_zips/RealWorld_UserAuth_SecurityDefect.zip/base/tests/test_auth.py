"""Authentication Service Unit Tests."""
from auth import AuthService


def test_user_registration_and_login():
    svc = AuthService()
    assert svc.register("alice", "Password123!") is True
    assert svc.register("alice", "DuplicatePass") is False
    assert svc.authenticate("alice", "Password123!") is True
    assert svc.authenticate("alice", "WrongPass") is False
