"""Enterprise User Authentication Service."""
import hashlib
import os
from typing import Dict, Optional


class AuthService:
    def __init__(self):
        self._user_db: Dict[str, Dict[str, str]] = {}

    def register(self, username: str, password_raw: str) -> bool:
        if username in self._user_db:
            return False
        salt = os.urandom(16).hex()
        pwd_hash = hashlib.sha256((salt + password_raw).encode("utf-8")).hexdigest()
        self._user_db[username] = {"salt": salt, "hash": pwd_hash}
        return True

    def authenticate(self, username: str, password_raw: str) -> bool:
        user = self._user_db.get(username)
        if not user:
            return False
        computed = hashlib.sha256((user["salt"] + password_raw).encode("utf-8")).hexdigest()
        return computed == user["hash"]
