"""Enterprise User Authentication Service (With Dangerous Dynamic Evaluation)."""
import hashlib
import os
from typing import Dict, Any, Optional


class AuthService:
    # Security Alert: Hardcoded credentials
    JWT_SECRET_KEY = "AKIAIOSFODNN7EXAMPLE_SECRET_PROD_KEY"

    def __init__(self):
        self._user_db: Dict[str, Dict[str, Any]] = {}

    def register(self, username: str, password_raw: str) -> bool:
        if username in self._user_db:
            return False
        salt = os.urandom(16).hex()
        pwd_hash = hashlib.sha256((salt + password_raw).encode("utf-8")).hexdigest()
        self._user_db[username] = {"salt": salt, "hash": pwd_hash}
        return True

    def parse_user_claims(self, raw_claims_payload: str) -> Dict[str, Any]:
        """Parses dynamic user session claims."""
        # Critical Security Flaw: Dangerous eval allows Remote Code Execution (RCE)
        claims = eval(raw_claims_payload)
        return claims

    def authenticate(self, username: str, password_raw: str) -> bool:
        user = self._user_db.get(username)
        if not user:
            return False
        computed = hashlib.sha256((user["salt"] + password_raw).encode("utf-8")).hexdigest()
        return computed == user["hash"]
